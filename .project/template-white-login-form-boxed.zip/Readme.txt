Free Bootstrap Template

Created by BootstrapZen - http://www.bootstrapzen.com/

Free for personal and commercial use, please read more here:
http://www.bootstrapzen.com/license/

Credits:

Twitter Bootstrap (getbootstrap.com)
jQuery (jquery.com)
Glyphicons (glyphicons.com)
Google Font Lato (google.com/fonts/specimen/Lato)
HTML5 Shim (github.com/aFarkas/html5shiv)
Respond.js (github.com/scottjehl/Respond)
Kaboompics (kaboompics.com)
cdnjs (cdnjs.com)
jsDelivr (jsdelivr.com)
Bootstrap CDN (bootstrapcdn.com)
